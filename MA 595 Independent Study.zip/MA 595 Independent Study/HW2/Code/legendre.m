function pv = legendre(n,z)

if n==0
    pv = 1;
else
pv = zeros(n+1,1);
c0 = 1-z;
c1 = 1-z^2;

for m=0:n
   npm = n + m; nmm = n - m; 
   pell = prod(nmm+1:npm)/factorial(m); pmn = pell;
   for ell=1:(n-m)
       pell = pell*(-1)*(nmm-ell+1)*(npm+ell)*c0/(2*ell*(m+ell));
       pmn = pmn + pell;
   end
   pv(m+1) = pmn*(-1)^m/2^m*(c1)^(m/2);
end
end
end

