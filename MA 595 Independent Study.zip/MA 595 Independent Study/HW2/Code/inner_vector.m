function cmn = inner_vector(x,x0,p)

% x0: center

cmn = zeros((p+1)^2,1);

xmx0 = x - x0;
r0 = norm(xmx0);
phi0 = atan2(xmx0(2),xmx0(1));
theta0 = acos(xmx0(3)/r0);
costheta0 = cos(theta0);

    for n=0:p
        assoc_lgd_n0 = legendre(n,costheta0);
        j = n^2+1; mrpn = (-r0)^n; % why? m1pn = (-1)^n; mrpn = (-1)^n*r0^n; rpn = m1pn*mrpn; 
        for m=0:n
            c = (-1)^m/factorial(n+abs(m))*mrpn*assoc_lgd_n0(m+1);
            if m>0
               cmn(j+n+m) = 2*c*cos(m*phi0);
               cmn(j+n-m) = 2*c*sin(m*phi0);
            else
                cmn(j+n+m) = c;
            end
        end
    end
    
end