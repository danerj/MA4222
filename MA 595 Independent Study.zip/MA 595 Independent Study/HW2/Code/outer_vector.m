function o = outer_vector(x,x0,p)

% x0: center

o = zeros((p+1)^2,1);

xmx0 = x - x0;
r = norm(xmx0);
phi = atan2(xmx0(2),xmx0(1));
theta = acos(xmx0(3)/r);
costheta = cos(theta);

    for n=0:p
        assoc_lgd_n = legendre(n,costheta);
        j = n^2+1; rpmnm1 = (-1)^n*1/r^(n+1);
        for m=0:n
            c = (-1)^(-m)*factorial(n-abs(m))*rpmnm1*assoc_lgd_n(m+1);
            if m>0
               o(j+n+m) = c*cos(m*phi);
               o(j+n-m) = c*sin(m*phi);
            else
                o(j+n+m) = c*cos(m*phi);
            end
        end
    end
    
end
