%% Spherical Harmonics Demo Part 1: Fix distance, vary p

clear all
close all
clc

p_vector = 3:8;
x0 = zeros(3,1); % this is our center
distance = 5; % (roughly) the distance between the two points xclose and xfar

for jj = 1:10

    x_close = rand(3,1); % this is the point that is close to xc
    x_far = rand(3,1); x_far(1) = x_far(1) + distance; % this is the point that is far away from xc

    true_solutions = ones(1,length(p_vector)) * 1 / norm(x_close-x_far); % direct calculation
    approximations = zeros(1,length(p_vector));
    t = zeros(1,length(p_vector));
    errors = zeros(1,length(p_vector));

    for ii = 1:length(p_vector)
        p = p_vector(ii); % Keep (p+1)^2 terms in the infinite series
        
        tic
        a = inner_vector(x_close,x0,p); % coefficient vector a(ii)
        b = outer_vector(x_far,x0,p); % coefficient vector b(ii)
        approximations(ii) = a'*b; % approximation of 1 / norm(x_close - x_far)
        t(ii) = toc;

        errors(ii) = norm(true_solutions(ii) - approximations(ii)) / norm(true_solutions(ii));
    end

    figure(1)
    set(gcf, 'Position', get(0, 'Screensize'));

    subplot(2,2,1)
    plot(p_vector, true_solutions, 'g+', p_vector, approximations, 'ro', 'linewidth', 2)
    title('$$y = 1/r$$ and approximation $$\hat{y}$$ increasing $$p$$ with distance fixed', 'interpreter', 'latex')
    xlabel('$p$', 'interpreter', 'latex')
    ylabel('$$y$$, $$\hat{y}$$', 'interpreter', 'latex')

    subplot(2,2,2)
    plot(p_vector, errors, 'x', 'linewidth', 2)
    title('Relative Error Approximating $$y = 1/r$$', 'interpreter', 'latex')
    xlabel('$p$', 'interpreter', 'latex')
    ylabel('$$\frac{||y-\hat{y}||}{||y||}$$', 'interpreter', 'latex')

    subplot(2,2,3)
    loglog(p_vector, errors, 'x', 'linewidth', 2)
    title('Relative Error Approximating $$y = 1/r$$ (loglog)', 'interpreter', 'latex')
    xlabel('$p$', 'interpreter', 'latex')
    ylabel('$$\frac{||y-\hat{y}||}{||y||}$$', 'interpreter', 'latex')

    subplot(2,2,4)
    plot(p_vector, t, 'm*', 'linewidth', 2)
    title('Time to calculate approximation $$\hat{y}$$', 'interpreter', 'latex')
    xlabel('$p$', 'interpreter', 'latex')
    ylabel('Computation time ($$t$$)', 'interpreter', 'latex')

    pause(2)
end

%% Spherical Harmonics Demo Part 2: Fix p, vary distance

clear all
close all
clc

p = 6; % Keep (p+1)^2 terms in the infinite series
distances = 1:7;
x0 = zeros(3,1); % this is our center

approximations = zeros(1, length(distances));
true_solutions = zeros(1, length(distances));
errors = zeros(1,length(distances));
t = zeros(1,length(distances));

for jj = 1:10

    for ii = 1:length(distances)
        distance = distances(ii);
        
        x_close = rand(3,1); % this is the point that is close to xc
        x_far = rand(3,1);
        x_far(1) = x_far(1) + distance;

        tic
        a = inner_vector(x_close,x0,p); % coefficient vector a(ii)
        b = outer_vector(x_far,x0,p); % coefficient vector b(ii)
        approximations(ii) = a'*b; % approximation
        t(ii) = toc;

        true_solutions(ii) = 1/norm(x_close-x_far); % direct calculation
        errors(ii) = norm(true_solutions(ii)-approximations(ii))/norm(true_solutions(ii)); % relative error
    end

    figure(2)
    set(gcf, 'Position', get(0, 'Screensize'));

    subplot(2,2,1)
    plot(distances, true_solutions, 'g+', distances, approximations, 'ro', 'linewidth', 2)
    title('$$y = 1/r$$ and approximation $$\hat{y}$$ increasing distance with $$p$$ fixed', 'interpreter', 'latex')
    xlabel('distance', 'interpreter', 'latex')
    ylabel('$$y$$, $$\hat{y}$$', 'interpreter', 'latex')

    subplot(2,2,2)
    plot(distances, errors, 'x', 'linewidth', 2)
    title('Relative Error Approximating $$y = 1/r$$', 'interpreter', 'latex')
    xlabel('distance', 'interpreter', 'latex')
    ylabel('$$\frac{||y-\hat{y}||}{||y||}$$', 'interpreter', 'latex')


    subplot(2,2,3)
    loglog(distances, errors, 'x', 'linewidth', 2)
    title('Relative Error Approximating $$y = 1/r$$ (loglog)', 'interpreter', 'latex')
    xlabel('distance', 'interpreter', 'latex')
    ylabel('$$\frac{||y-\hat{y}||}{||y||}$$', 'interpreter', 'latex')

    subplot(2,2,4)
    plot(distances, t, 'm*', 'linewidth', 2)
    title('Time to calculate approximation $$\hat{y}$$', 'interpreter', 'latex')
    xlabel('$p$', 'interpreter', 'latex')
    ylabel('Computation time ($$t$$)', 'interpreter', 'latex')

    pause(1)
end

%% Fast Multipole Method Demo Part 1: Fix distance, vary p

clear all
close all
clc

n = 1000;
distance = 5;
p_vector = 2:7;
t = zeros(2,length(p_vector));
errors = zeros(1,length(p_vector));

x0 = zeros(3,1); % center of the source points
X_close = 2*rand(3,n);
X_close = X_close - [1 1 1]';
X_far = 2*rand(3,n);
X_far = X_far - [1 1 1]';
X_far(1,:) = X_far(1,:) + distance;
q = rand(n,1); % each source point has a charge q_i

for kk = 1:length(p_vector)
    
    p = p_vector(kk);

    % total potential of each evaluation point: estimated and exact, two vectors 
    Q_approximation = zeros(n,1);

    c = zeros((p+1)^2,n);
    % FMM: two seperate for loops, O(N)
    tic
    for ii = 1:n
        c(:,ii) = inner_vector(X_close(:,ii),x0,p)*q(ii);
    end
    Q_cluster = sum(c,2); % total "contribution" of the source cluster
    for ii=1:n
        temp = outer_vector(X_far(:,ii),x0,p);
        Q_approximation(ii) = Q_cluster'*temp; % calculate the potential of the (ii)th evaluation point
    end
    t(1, kk) = toc;

    % direct: one nested for loop, O(N^2)
    % formula for calculating the potential at XFAR(:,jj):
    % sum over ii: charge at XCLOSE(:,ii) / distance between XCLOSE(:,ii) and XFAR(:,jj) 
    Q_true = zeros(n,1);
    tic
    for ii=1:n
        qtemp = 0;
        % calculate the potential of the (ii)th evaluation point
        for jj=1:n
            qtemp = qtemp + q(jj)/norm(X_close(:,jj)-X_far(:,ii));
        end
        Q_true(ii) = qtemp;
    end
    t(2,kk) = toc;

    % relative error of FMM
    errors(kk) = norm(Q_true-Q_approximation)/norm(Q_true);

end

% graph both clusters
figure(3)
set(gcf, 'Position', get(0, 'Screensize'));
subplot(2,2,1)
plot3(X_close(1,:),X_close(2,:),X_close(3,:),'+', X_far(1,:),X_far(2,:),X_far(3,:),'r.') % source
axis equal
legend('X_{close}', 'X_{far}')

subplot(2,2,2)
plot(p_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,3)
loglog(p_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$ (loglog)', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,4)
plot(p_vector, t(1,:),'c*', p_vector, t(2,:), 'm*', 'linewidth', 2)
title('Time to calculate approximation $$Q$$, $$\hat{Q}$$', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('Computation time ($$t$$)', 'interpreter', 'latex')
legend({'$$\hat{Q}$$', 'Q'}, 'interpreter', 'latex', 'location', 'east')

%% Fast Multipole Method Demo Part 2: Fix p, vary distance

clear all
close all
clc

n = 1000;
p = 5;
distances = 1:6;
t = zeros(2,length(distances));
errors = zeros(1,length(distances));
q_norms = zeros(2,length(distances));

x0 = zeros(3,1); % center of the source points
X_close = 2*rand(3,n);
X_close = X_close - [1 1 1]';
X_far = 2*rand(3,n);
X_far = X_far - [1 1 1]';
% each source point has a charge qi
q = rand(n,1);

for kk = 1:length(distances)
    
    X_far(1,:) = X_far(1,:) + 1;

    % total potential of each evaluation point: estimated and exact, two vectors 
    Q_approximation = zeros(n,1);

    c = zeros((p+1)^2,n);
    % FMM: two seperate for loops, O(N)
    tic
    for ii = 1:n
        c(:,ii) = inner_vector(X_close(:,ii),x0,p)*q(ii);
    end
    Q_cluster = sum(c,2); % total "contribution" of the source cluster
    for ii=1:n
        temp = outer_vector(X_far(:,ii),x0,p);
        Q_approximation(ii) = Q_cluster'*temp; % calculate the potential of the (ii)th evaluation point
    end
    t(1, kk) = toc;

    % direct: one nested for loop, O(N^2)
    % formula for calculating the potential at XFAR(:,jj):
    % sum over ii: charge at XCLOSE(:,ii) / distance between XCLOSE(:,ii) and XFAR(:,jj) 
    Q_true = zeros(n,1);
    tic
    for ii=1:n
        qtemp = 0;
        % calculate the potential of the (ii)th evaluation point
        for jj=1:n
            qtemp = qtemp + q(jj)/norm(X_close(:,jj)-X_far(:,ii));
        end
        Q_true(ii) = qtemp;
    end
    t(2,kk) = toc;

    % relative error of FMM
    q_norms(:,kk) = [norm(Q_approximation), norm(Q_true)]';
    errors(kk) = norm(Q_true-Q_approximation)/norm(Q_true);

end

% graph both clusters
figure(3)
set(gcf, 'Position', get(0, 'Screensize'));

subplot(2,2,1)
plot(distances, q_norms(1,:), 'g+', distances, q_norms(2,:), 'ro', 'linewidth', 2)
title('Comparing $$||Q_{FMM}||$$ and $$||Q_{true}||$$ as distance increases', 'interpreter', 'latex')
xlabel('cluster distance', 'interpreter', 'latex')
ylabel('$$||Q_{FMM}||$$, $$||Q_{true}||$$', 'interpreter', 'latex')
legend({'$$||Q_{FMM}||$$', '$$||Q_{true}||$$'}, 'interpreter', 'latex')

subplot(2,2,2)
plot(distances, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$', 'interpreter', 'latex')
xlabel('cluster distance', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,3)
loglog(distances, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$ (loglog)', 'interpreter', 'latex')
xlabel('cluster distance', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,4)
plot(distances, t(1,:),'c*', distances, t(2,:), 'm*', 'linewidth', 2)
title('Time to calculate approximation $$Q$$, $$\hat{Q}$$', 'interpreter', 'latex')
xlabel('cluster distance', 'interpreter', 'latex')
ylabel('Computation time ($$t$$)', 'interpreter', 'latex')
legend({'$$\hat{Q}$$', 'Q'}, 'interpreter', 'latex', 'location', 'east')

%% Fast Multipole Method Demo Part 1: Fix distance, vary p

clear all
close all
clc

n = 1000;
distance = 5;
p_vector = 2:7;
t = zeros(2,length(p_vector));
errors = zeros(1,length(p_vector));

x0 = zeros(3,1); % center of the source points
X_close = 2*rand(3,n);
X_close = X_close - [1 1 1]';
X_far = 2*rand(3,n);
X_far = X_far - [1 1 1]';
X_far(1,:) = X_far(1,:) + distance;
% each source point has a charge qi
q = rand(n,1);

for kk = 1:length(p_vector)
    
    p = p_vector(kk);

    % total potential of each evaluation point: estimated and exact, two vectors 
    Q_approximation = zeros(n,1);

    c = zeros((p+1)^2,n);
    % FMM: two seperate for loops, O(N)
    tic
    for ii = 1:n
        c(:,ii) = inner_vector(X_close(:,ii),x0,p)*q(ii);
    end
    Q_cluster = sum(c,2); % total "contribution" of the source cluster
    for ii=1:n
        temp = outer_vector(X_far(:,ii),x0,p);
        Q_approximation(ii) = Q_cluster'*temp; % calculate the potential of the (ii)th evaluation point
    end
    t(1, kk) = toc;

    % direct: one nested for loop, O(N^2)
    % formula for calculating the potential at XFAR(:,jj):
    % sum over ii: charge at XCLOSE(:,ii) / distance between XCLOSE(:,ii) and XFAR(:,jj) 
    Q_true = zeros(n,1);
    tic
    for ii=1:n
        qtemp = 0;
        % calculate the potential of the (ii)th evaluation point
        for jj=1:n
            qtemp = qtemp + q(jj)/norm(X_close(:,jj)-X_far(:,ii));
        end
        Q_true(ii) = qtemp;
    end
    t(2,kk) = toc;

    % relative error of FMM
    errors(kk) = norm(Q_true-Q_approximation)/norm(Q_true);

end

% graph both clusters
figure(3)
set(gcf, 'Position', get(0, 'Screensize'));
subplot(2,2,1)
plot3(X_close(1,:),X_close(2,:),X_close(3,:),'+', X_far(1,:),X_far(2,:),X_far(3,:),'r.') % source
axis equal
legend('X_{close}', 'X_{far}')

subplot(2,2,2)
plot(p_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,3)
loglog(p_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$ (loglog)', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,4)
plot(p_vector, t(1,:),'c*', p_vector, t(2,:), 'm*', 'linewidth', 2)
title('Time to calculate approximation $$Q$$, $$\hat{Q}$$', 'interpreter', 'latex')
xlabel('$p$', 'interpreter', 'latex')
ylabel('Computation time ($$t$$)', 'interpreter', 'latex')
legend({'$$\hat{Q}$$', 'Q'}, 'interpreter', 'latex', 'location', 'east')

%% Fast Multipole Method Demo Part 3: Vary n

clear all
close all
clc

n_vector = [10, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
p = 3;
distance = 5;
t = zeros(2,length(n_vector));
errors = zeros(1,length(n_vector));
q_norms = zeros(2,length(n_vector));


for kk = 1:length(n_vector)
    
    n = n_vector(kk);
    
    x0 = zeros(3,1); % center of the source points
    X_close = 2*rand(3,n);
    X_close = X_close - [1 1 1]';
    X_far = 2*rand(3,n);
    X_far = X_far - [1 1 1]';
    % each source point has a charge qi
    q = rand(n,1);
    X_far(1,:) = X_far(1,:) + distance;

    % total potential of each evaluation point: estimated and exact, two vectors 
    Q_approximation = zeros(n,1);

    c = zeros((p+1)^2,n);
    % FMM: two seperate for loops, O(N)
    tic
    for ii = 1:n
        c(:,ii) = inner_vector(X_close(:,ii),x0,p)*q(ii);
    end
    Q_cluster = sum(c,2); % total "contribution" of the source cluster
    for ii=1:n
        temp = outer_vector(X_far(:,ii),x0,p);
        Q_approximation(ii) = Q_cluster'*temp; % calculate the potential of the (ii)th evaluation point
    end
    t(1, kk) = toc;

    % direct: one nested for loop, O(N^2)
    % formula for calculating the potential at XFAR(:,jj):
    % sum over ii: charge at XCLOSE(:,ii) / distance between XCLOSE(:,ii) and XFAR(:,jj) 
    Q_true = zeros(n,1);
    tic
    for ii=1:n
        qtemp = 0;
        % calculate the potential of the (ii)th evaluation point
        for jj=1:n
            qtemp = qtemp + q(jj)/norm(X_close(:,jj)-X_far(:,ii));
        end
        Q_true(ii) = qtemp;
    end
    t(2,kk) = toc;

    % relative error of FMM
    q_norms(:,kk) = [norm(Q_approximation), norm(Q_true)]';
    errors(kk) = norm(Q_true-Q_approximation)/norm(Q_true);

end

% graph both clusters
figure(3)
set(gcf, 'Position', get(0, 'Screensize'));

subplot(2,2,1)
plot(n_vector, q_norms(1,:), 'g+', n_vector, q_norms(2,:), 'ro', 'linewidth', 2)
title('Comparing $$||Q_{FMM}||$$ and $$||Q_{true}||$$ as distance increases', 'interpreter', 'latex')
xlabel('matrix size $$n \times n$$', 'interpreter', 'latex')
ylabel('$$||Q_{FMM}||$$, $$||Q_{true}||$$', 'interpreter', 'latex')
legend({'$$||Q_{FMM}||$$', '$$||Q_{true}||$$'}, 'interpreter', 'latex')

subplot(2,2,2)
plot(n_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$', 'interpreter', 'latex')
xlabel('matrix size $$n \times n$$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,3)
loglog(n_vector, errors, 'x', 'linewidth', 2)
title('Relative Error Approximating $$Q$$ (loglog)', 'interpreter', 'latex')
xlabel('matrix size $$n \times n$$', 'interpreter', 'latex')
ylabel('$$\frac{||Q-\hat{Q}||}{||Q||}$$', 'interpreter', 'latex')

subplot(2,2,4)
plot(n_vector, t(1,:),'c*', n_vector, t(2,:), 'm*', 'linewidth', 2)
title('Time to calculate approximation $$Q$$, $$\hat{Q}$$', 'interpreter', 'latex')
xlabel('matrix size $$n \times n$$', 'interpreter', 'latex')
ylabel('Computation time ($$t$$)', 'interpreter', 'latex')
legend({'$$\hat{Q}$$', 'Q'}, 'interpreter', 'latex', 'location', 'east')

figure(4)
plot(n_vector, t(1,:),'c*', 'linewidth', 2)
title('Time to calculate approximation $$\hat{Q}$$', 'interpreter', 'latex')
xlabel('matrix size $$n \times n$$', 'interpreter', 'latex')
ylabel('Computation time ($$t$$)', 'interpreter', 'latex')