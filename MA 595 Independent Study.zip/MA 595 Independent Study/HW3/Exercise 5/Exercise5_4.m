for trials = 1:3
    clear all
    % (a)
    tic
    n = 10^2;
    A = rand(n, n);
    z = rand(n^2, 1);
    minimum_singular_values = zeros(1, n^2);

    for jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end
    toc

    % (b)
    clear all

    tic
    parpool(4)
    n = 10^2;
    A = rand(n, n);
    z = rand(n^2, 1);
    minimum_singular_values = zeros(1, n^2);

    parfor jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end
    toc
    delete(gcp)

    % (c)
    clear all

    tic
    n = 10^2;
    A = gpuArray(rand(n, n));
    z = gpuArray(rand(n^2, 1));
    minimum_singular_values = gpuArray(zeros(1, n^2));

    for jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end
    toc
end