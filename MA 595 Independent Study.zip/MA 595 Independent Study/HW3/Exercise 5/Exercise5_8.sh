#!/bin/bash
#SBATCH --output=Exercise5_8.out
#SBATCH --error=Exercise5_8.err
#SBATCH -C K40
#SBATCH --gres=gpu:1
#SBATCH --mem 64G
#SBATCH --ntasks-per-node=8
#SBATCH --gres=gpu:1
#SBATCH -p short
#SBATCH -t 1:00:00

module load matlab

matlab -nodisplay -nosplash < Exercise5_8.m
