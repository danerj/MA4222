%% Exercise 2

clear all
close all
clc

eps_estimate = 1;
while eps_estimate / 2 + 1 > 1
    eps_estimate = eps_estimate / 2;
end
eps_estimate
eps(1)

%% Exercise 4

clear all
close all
clc
format long

alpha = single(2e-3);
b = [2-alpha; 2+alpha];
A = [1 1-alpha; 1+alpha 1];

Ab = [A b];
Ab(1,:) = Ab(1,:) / Ab(1,1);
pivot = Ab(2,1) / Ab(1,1);
Ab(2,:) = Ab(2,:) - pivot * Ab(1,:);
pivot = Ab(1,2) / Ab(2,2);
Ab(1,:) = Ab(1,:) - pivot * Ab(2,:);
Ab(2,:) = Ab(2,:) / Ab(2,2);
x = Ab(:,3)

clear all

alpha = 2e-3;
b = [2-alpha; 2+alpha];
A = [1 1-alpha; 1+alpha 1];

Ab = [A b];
Ab(1,:) = Ab(1,:) / Ab(1,1);
pivot = Ab(2,1) / Ab(1,1);
Ab(2,:) = Ab(2,:) - pivot * Ab(1,:);
pivot = Ab(1,2) / Ab(2,2);
Ab(1,:) = Ab(1,:) - pivot * Ab(2,:);
Ab(2,:) = Ab(2,:) / Ab(2,2);
x = Ab(:,3)

%% Exercise 5

clear all
close all
clc

for trials = 1:3
    clear all
    
    % (a)
    tic
    n = 10^2;
    A = rand(n, n);
    z = rand(n^2, 1);
    minimum_singular_values = zeros(1, n^2);

    for jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end

    toc

    minimum_singular_values(1:10)

    % (b)
    clear all

    tic
    parpool(2)
    n = 10^2;
    A = rand(n, n);
    z = rand(n^2, 1);
    minimum_singular_values = zeros(1, n^2);

    parfor jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end

    toc
    minimum_singular_values(1:10)
    delete(gcp)


    % (c)
    clear all

    tic
    n = 10^2;
    A = gpuArray(rand(n, n));
    z = gpuArray(rand(n^2, 1));
    minimum_singular_values = gpuArray(zeros(1, n^2));

    for jj = 1:n^2

        minimum_singular_values(jj) = min(svd(A - z(jj)*eye(n)));

    end

    toc
    minimum_singular_values(1:10)
end

%% Exercise 7

clear all
close all
clc

A = [0 2; 2 0; 1 3; 3 1]

[U, Sigma, V] = svd(A)

% Write out the reduced SVD that was computed by hand
U_hat = [1/sqrt(10) -1/2; 1/sqrt(10) 1/2; 2/sqrt(10) -1/2; 2/sqrt(10) 1/2]
Sigma_hat = [2*sqrt(5) 0; 0 2*sqrt(2)]
V_hat = [1 1; 1 -1]/sqrt(2)

% Check that the reduced SVD I found correctly recovers A
U_hat*Sigma_hat*V_hat

% Check that the columns of U are orthonormal
U_hat(:,1)' * U_hat(:,2)
norm(U_hat(:,1))
norm(U_hat(:,2))

% Check that the columns of V are orthonormal
V_hat(:,1)' * V_hat(:,2)
norm(V_hat(:,1))
norm(V_hat(:,2))

% Write out the full SVD that I found by hand
U_full = [1/sqrt(10) 1/sqrt(10) 2/sqrt(10) 2/sqrt(10);
    -1/2 1/2 -1/2 1/2;
    -2/sqrt(10) -2/sqrt(10) 1/sqrt(10) 1/sqrt(10);
    -1/2 1/2 1/2 -1/2]'

Sigma_full = [Sigma_hat; 0 0; 0 0]

V_full = V_hat

% Check that U and V are unitary
U'*U
V'*V

% Check that the full svd was computed correctly
U_full*Sigma_full*V_full'

%% Exercise 13
% (a)

clear all
close all
clc

t = (0:0.3:3).';
y = [0.998, 0.623, 0.364, 0.1, 0.27, 0.1533, 0.362, 0.375, 0.146, 0.033, -0.509]';

A = fliplr(vander(t));
A = A(:,1:4);

ATransposeA = A'*A
condition_number_ATA = cond(A'*A)

tic
L = chol(A'*A, 'lower');
z = A.'*y;
d = L \ z;
c = L.' \ d;
coefficients_cholesky = c
cholesky_computation_time = toc

t_space = linspace(0,3);
subplot(1,2,1)
plot(t, y, 'x', t_space, polyval(flip(c),t_space), 'linewidth', 2)
title('Problem 13a: Least Squares using Cholesky Decomposition',...
    'interpreter', 'latex')
xlabel('$t$', 'interpreter', 'latex')
ylabel('$y$, $\hat{y}$', 'interpreter', 'latex')
legend({'$y_i$', '$\hat{y}(t)$'}, 'interpreter', 'latex')

% (b)

condition_number_A = cond(A)

tic
[Q, R] = qr(A);
z = Q'*y;
c = R \ z;
coefficients_qr = c
qr_computation_time = toc

subplot(1,2,2)
plot(t, y, 'x', t_space, polyval(flip(c),t_space), 'linewidth', 2)
title('Problem 13b: Least Squares using QR Decomposition',...
    'interpreter', 'latex')
xlabel('$t$', 'interpreter', 'latex')
ylabel('$y$, $\hat{y}$', 'interpreter', 'latex')
legend({'$y_i$', '$\hat{y}(t)$'}, 'interpreter', 'latex')