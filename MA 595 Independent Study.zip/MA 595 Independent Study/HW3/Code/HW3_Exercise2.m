eps_estimate = 1;
while eps_estimate / 2 + 1 > 1
    eps_estimate = eps_estimate / 2;
end
eps_estimate
eps(1)