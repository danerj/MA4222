format long

alpha = single(2e-3);
b = [2-alpha; 2+alpha];
A = [1 1-alpha; 1+alpha 1];

Ab = [A b];
Ab(1,:) = Ab(1,:) / Ab(1,1);
pivot = Ab(2,1) / Ab(1,1);
Ab(2,:) = Ab(2,:) - pivot * Ab(1,:);
pivot = Ab(1,2) / Ab(2,2);
Ab(1,:) = Ab(1,:) - pivot * Ab(2,:);
Ab(2,:) = Ab(2,:) / Ab(2,2);
x = Ab(:,3)

clear all

alpha = 2e-3;
b = [2-alpha; 2+alpha];
A = [1 1-alpha; 1+alpha 1];
cond(A)

Ab = [A b];
Ab(1,:) = Ab(1,:) / Ab(1,1);
pivot = Ab(2,1) / Ab(1,1);
Ab(2,:) = Ab(2,:) - pivot * Ab(1,:);
pivot = Ab(1,2) / Ab(2,2);
Ab(1,:) = Ab(1,:) - pivot * Ab(2,:);
Ab(2,:) = Ab(2,:) / Ab(2,2);
x = Ab(:,3)