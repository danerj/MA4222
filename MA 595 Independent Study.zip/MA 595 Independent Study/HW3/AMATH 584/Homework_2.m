clear all
close all
clc

% Construcing low-rank approximations of a matrix X using a SVD of X,
% where X stores the data necessary to display an image of a painting.

imagedemo;
title('Full Rank Image', 'interpreter', 'latex')

[U, Sigma, V] = svd(X);

X_1 = (U(:,1))*Sigma(1,1)*(V(:,1))';
X_10 = (U(:,1:10))*Sigma(1:10,1:10)*(V(:,1:10))';
X_25 = (U(:,1:25))*Sigma(1:25,1:25)*(V(:,1:25))';
X_50 = (U(:,1:50))*Sigma(1:50,1:50)*(V(:,1:50))';
X_100 = (U(:,1:100))*Sigma(1:100,1:100)*(V(:,1:100))';
X_200 = (U(:,1:200))*Sigma(1:200,1:200)*(V(:,1:200))';

figure(2)
colormap(map)

subplot(2,2,1)
imagesc(X_1)
axis off;
title('Rank 1 Approximation', 'interpreter', 'latex')
subplot(2,2,2)
imagesc(X_10)
axis off;
title('Rank 10 Approximation', 'interpreter', 'latex')
subplot(2,2,3)
imagesc(X_25)
axis off;
title('Rank 25 Approximation', 'interpreter', 'latex')
subplot(2,2,4)
imagesc(X_50)
axis off;
title('Rank 50 Approximation', 'interpreter', 'latex')


figure(3)
colormap(map)

subplot(1,3,1)
imagesc(X_100)
axis off;
title('Rank 100 Approximation', 'interpreter', 'latex')
subplot(1,3,2)
imagesc(X_200)
title('Rank 200 Approximation', 'interpreter', 'latex')
axis off;
subplot(1,3,3)
imagesc(X)
title('Rank 509 (Full Rank) Approximation', 'interpreter', 'latex')
axis off;