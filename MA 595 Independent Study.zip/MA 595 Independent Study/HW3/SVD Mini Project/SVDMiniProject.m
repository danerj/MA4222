%Using SVD to compress an image
close all;
clear all;
clc
%imread reads a picture as a matrix
%double is used to make sure we use double precision for SVD calculations
c = double(imread('CloudyGoldenGate_Grayscale.jpg'));
b = double(imread('Barton_St_Macclesfield.jpg'));

%show command creates a picture from the matrix
figure(1)
show(c, b, 1);

PSNR = zeros(2,length(5:5:30));
%determine the number of singular values
for k = 5:5:30

%passing the image matrix as double to "compress" to k singular values
%returns U_k and R_k=Sigma_k*V_k^T for picture e and then for picture b
[ukc rkc Dkc] = compressimagek(c, k);
[ukb rkb Dkb] = compressimagek(b, k);

%passing the compressed matrices to be multiplied and determine matrix for
%image approximation
ck = decompressimagek(ukc, rkc);
bk = decompressimagek(ukb, rkb);

RMSE_bk = 0;
for ii = 1:893
    for jj = 1:1280
        RMSE_bk = RMSE_bk + (b(ii,jj) - bk(ii,jj))^2;
    end
end
RMSE_bk = sqrt(RMSE_bk / (893*1280));
PSNR(1, k / 5) = 10*log10(255^2 / RMSE_bk);

RMSE_ck = 0;
for ii = 1:384
    for jj = 1:500
        RMSE_ck = RMSE_ck + (c(ii,jj) - ck(ii,jj))^2;
    end
end
RMSE_ck = sqrt(RMSE_ck / (893*1280));
PSNR(2, k / 5) = 10*log10(255^2 / RMSE_ck);
end

%graphing the uncompressed images
figure(2)
show(ck, bk, 2)

[U_b, Sigma_b, V_b] = svd(b);
[U_c, Sigma_c, V_c] = svd(c);

normalized_singular_values_b = diag(Sigma_b) / max(diag(Sigma_b));
normalized_singular_values_c = diag(Sigma_c) / max(diag(Sigma_c));
figure(3)
subplot(1,2,1)
plot(normalized_singular_values_b(1:30), 'go')
title('30 largest singular values image a', 'interpreter', 'latex')
xlabel('k', 'interpreter', 'latex')
ylabel('$\sigma_k$', 'interpreter', 'latex')
subplot(1,2,2)
plot(normalized_singular_values_c(1:30), 'ro')
title('30 largest singular values image b', 'interpreter', 'latex')
xlabel('k', 'interpreter', 'latex')
ylabel('$\sigma_k$', 'interpreter', 'latex')

% Functions
function [u r D] = compressimagek(img, k)

[u s v] = svd(img, 0);
D=diag(s);
u = u(:, 1:k);
r = s(1:k, 1:k) * v(:, 1:k)';
end

function img = decompressimagek(u, r)
img = u * r;
end

function show(img1, img2, fig)

if nargin < 3
    fig = 1;
end

figure(fig); clf; colormap(gray)
subplot(1, 2, 1); imagesc(img1); axis image; axis off
subplot(1, 2, 2); imagesc(img2); axis image; axis off
end