#!/bin/bash
#SBATCH --output=simple.out
#SBATCH --error=simple.err
#SBATCH -C K20
#SBATCH --gres=gpu:1
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -p short
#SBATCH -t 1:00:00

module load matlab

matlab -nojvm -nodisplay -nosplash < simple.m
