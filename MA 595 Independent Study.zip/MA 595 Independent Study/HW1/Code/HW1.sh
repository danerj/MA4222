#!/bin/bash
#SBATCH --output=HW1.out
#SBATCH --error=HW1.err
#SBATCH -C K80
#SBATCH --gres=gpu:1
#SBATCH --mem 64G
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -p short
#SBATCH -t 1:00:00

module load matlab

matlab -nojvm -nodisplay -nosplash < HW1.m
