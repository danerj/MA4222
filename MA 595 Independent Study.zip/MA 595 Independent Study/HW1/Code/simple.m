clear all
close all
clc

A = rand(5,5)
b = rand(5,1)

x = A \ b
