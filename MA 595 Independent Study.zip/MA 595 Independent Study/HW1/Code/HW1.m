clear all
close all
clc

for jj = 1:6
    T = zeros(3,5);
    n_array = [10^2, 10^3, 10^4];
    
    for ii = 1:length(n_array)
        
        n = n_array(ii);
        b = rand(n,1);
        
        %(a)
        A = rand(n,n);
        tic
        x = A \ b;
        T(ii,1) = toc;
        
        %(b)
        A = gpuArray(A);
        tic
        x = A \ b;
        T(ii,2) = toc;
        
        %(c i)
        A = 4*eye(n,n) - diag(ones(1,n-1), -1)...
            - diag(ones(1,n-1), 1);
        tic
        x = A \ b;
        T(ii,3) = toc;
        
        %(c ii)
        A = zeros(n,n,'gpuArray');
        A = A + 4*eye(n,n,'gpuArray') - diag(ones(1,n-1,'gpuArray'), -1)...
            - diag(ones(1,n-1,'gpuArray'), 1);
        tic
        x = A \ b;
        T(ii,4) = toc;
        
        %(c iii)
        e = ones(n,1);
        A = spdiags([-e 4*e -e],-1:1,n,n);
        tic
        x = A \ b;
        T(ii,5) = toc;
        
    end
    T
end